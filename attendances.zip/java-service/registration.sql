-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: 2020-10-24 07:42:58
-- 服务器版本： 5.7.19
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registration`
--

-- --------------------------------------------------------

--
-- 表的结构 `attendance`
--

DROP TABLE IF EXISTS `attendance`;
CREATE TABLE IF NOT EXISTS `attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `downaddress` varchar(255) DEFAULT NULL,
  `eid` int(11) NOT NULL,
  `upaddress` varchar(255) DEFAULT NULL,
  `workdown` varchar(255) DEFAULT NULL,
  `worktime` varchar(255) DEFAULT NULL,
  `workup` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `attendance`
--

INSERT INTO `attendance` (`id`, `downaddress`, `eid`, `upaddress`, `workdown`, `worktime`, `workup`, `status`) VALUES
(59, '天津市津南区S107(津港公路) 津南区政府内,津南区监察委员会附近0米', 10, '天津市津南区S107(津港公路) 津南区政府内,津南区监察委员会附近0米', '12:47', '2020-10-19', '12:47', '0'),
(58, '天津市津南区S107(津港公路) 津南区政府内,津南区监察委员会附近0米', 1, '天津市津南区S107(津港公路) 津南区政府内,津南区监察委员会附近0米', '12:47', '2020-10-19', '12:47', '0'),
(62, '天津市津南区S107(津港公路) 津南区政府内,津南区监察委员会附近0米', 36, '天津市津南区S107(津港公路) 津南区政府内,津南区监察委员会附近0米', '13:18', '2020-10-19', '13:18', '0'),
(57, '天津市津南区S107(津港公路) 津南区政府内,津南区监察委员会附近0米', 30, '天津市津南区S107(津港公路) 津南区政府内,津南区监察委员会附近0米', '12:47', '2020-10-19', '12:47', '2'),
(64, '天津市津南区S107(津港公路) 津南区政府内,津南区监察委员会附近0米', 2, '天津市津南区S107(津港公路) 津南区政府内,津南区监察委员会附近0米', '14:19', '2020-10-19', '14:19', '0'),
(54, '天津市津南区S107(津港公路) 津南区政府内,津南区监察委员会附近0米', 36, '天津市津南区S107(津港公路) 津南区政府内,津南区监察委员会附近0米', '12:46', '2020-10-19', '12:46', '0'),
(55, '', 13, '天津市津南区S107(津港公路) 津南区政府内,津南区监察委员会附近0米', '', '2020-10-19', '12:46', '2'),
(56, '天津市津南区S107(津港公路) 津南区政府内,津南区监察委员会附近0米', 3, '天津市津南区S107(津港公路) 津南区政府内,津南区监察委员会附近0米', '12:46', '2020-10-19', '12:46', '1'),
(60, '天津市津南区S107(津港公路) 津南区政府内,津南区监察委员会附近0米', 13, '天津市津南区S107(津港公路) 津南区政府内,津南区监察委员会附近0米', '12:55', '2020-10-19', '12:55', '0'),
(63, '', 2, '天津市津南区S107(津港公路) 津南区政府内,津南区监察委员会附近0米', '', '2020-10-19', '13:23', '2');

-- --------------------------------------------------------

--
-- 表的结构 `bussiness`
--

DROP TABLE IF EXISTS `bussiness`;
CREATE TABLE IF NOT EXISTS `bussiness` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `how_long` varchar(255) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `time_end` varchar(255) DEFAULT NULL,
  `time_start` varchar(255) DEFAULT NULL,
  `uid` int(11) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `bussiness`
--

INSERT INTO `bussiness` (`id`, `how_long`, `reason`, `time_end`, `time_start`, `uid`, `address`, `name`) VALUES
(34, NULL, '', '2020-11-1', '2020-10-1', 2, '', NULL),
(30, NULL, '谈生意', '2020-11-1', '2020-10-30', 2, '北京', NULL),
(31, NULL, '见客户', '2020-10-4', '2020-10-3', 36, '天津', NULL),
(32, NULL, '介绍产品', '2020-11-13', '2020-11-2', 13, '上海', NULL),
(33, NULL, '公派', '2020-10-3', '2020-10-1', 30, '北京', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `eleave`
--

DROP TABLE IF EXISTS `eleave`;
CREATE TABLE IF NOT EXISTS `eleave` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `how_long` varchar(255) DEFAULT NULL,
  `leave_type` varchar(255) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `reply` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `time_end` varchar(255) DEFAULT NULL,
  `time_start` varchar(255) DEFAULT NULL,
  `uid` int(11) NOT NULL,
  `deal` varchar(255) DEFAULT NULL,
  `create_time` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `eleave`
--

INSERT INTO `eleave` (`id`, `how_long`, `leave_type`, `reason`, `reply`, `status`, `time_end`, `time_start`, `uid`, `deal`, `create_time`, `name`) VALUES
(43, NULL, '事假', '123', NULL, '0', '2020-10-10', '2020-10-1', 2, NULL, '2020年10月19日', NULL),
(42, NULL, '产假', '111', NULL, '0', '2020-10-9', '2020-10-3', 30, NULL, '2020年10月19日', NULL),
(35, NULL, '事假', '家里有事', NULL, '0', '2020-11-28', '2020-10-20', 2, NULL, '2020年10月19日', NULL),
(36, NULL, '婚假', '去结婚', NULL, '0', '2020-11-1', '2020-10-24', 2, NULL, '2020年10月19日', NULL),
(37, NULL, '年假', '过年了', NULL, '0', '2021-11-27', '2020-11-18', 2, NULL, '2020年10月19日', NULL),
(38, NULL, '丧假', '父母去世', NULL, '2', '2020-11-1', '2020-10-3', 36, '2', NULL, NULL),
(39, NULL, '陪产假', '老婆生孩子', '112213', '1', '2020-11-4', '2020-11-3', 36, '1', NULL, NULL),
(40, NULL, '年假', '', NULL, '2', '2020-11-2', '2020-11-1', 13, '2', NULL, NULL),
(41, NULL, '年假', '', '', '1', '2020-11-21', '2020-11-1', 3, '1', NULL, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE IF NOT EXISTS `employee` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `gender` int(11) DEFAULT NULL,
  `jointime` varchar(255) DEFAULT NULL,
  `num` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `role` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `age` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `employee`
--

INSERT INTO `employee` (`id`, `address`, `department`, `email`, `gender`, `jointime`, `num`, `password`, `phone`, `position`, `role`, `username`, `age`) VALUES
(1, '西藏', '董事会', '787913269@qq.com', 1, '2020年10月8日', 'H001', '123456', '15977602749', '老板', 1, '王富贵', '22'),
(2, '上海', '开发部门', '787913269@qq.com', 1, '2020年10月8日', '1', '123456', '15834602448', '后端', 0, '张富贵', '19'),
(13, '湖南', '人事部', '1', 1, '2020年10月8日', '3', '123456', '15977602749', '前端', 0, '梁朝伟', '20'),
(3, '广东', '人事部', '1', 1, '2020年10月8日', '4', '123456', '15977602749', '前端', 0, '谢霆锋', '21'),
(10, '北京', '开发部', '787913269@qq.com', 0, '2020年10月8日', 'H002', '123456', '15977602749', '后端', 1, '李志', '22'),
(9, '广西', '开发部', '787913269@qq.com', 0, '2020年10月8日', 'H003', '123456', '15977602749', '后端', 1, '吴彦祖', '23'),
(30, '广西', '销售部', '1555786474@qq.com', 0, '2020年10月8日', '5', '123456', '18677602749', '销售人员', 0, '何富贵', '32'),
(36, '', '销售部', '', 1, '2020-10-19', '2', '123456', '123456789', '销售', 0, '李狗蛋', '20');

-- --------------------------------------------------------

--
-- 表的结构 `notice`
--

DROP TABLE IF EXISTS `notice`;
CREATE TABLE IF NOT EXISTS `notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bid` varchar(255) DEFAULT NULL,
  `msg` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `notice`
--

INSERT INTO `notice` (`id`, `bid`, `msg`, `time`, `title`, `name`) VALUES
(42, '10', '放三天', '2020-10-19', '51放假通知', NULL),
(43, '10', '放七天', '2020-10-19', '春节放假通知', NULL),
(40, '1', '', '2020-10-19', '国庆放假通知', NULL),
(41, '1', '', '2020-10-19', '国庆放假通知2', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `pcontact`
--

DROP TABLE IF EXISTS `pcontact`;
CREATE TABLE IF NOT EXISTS `pcontact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `age` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `ps` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `wechat` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `pcontact`
--

INSERT INTO `pcontact` (`id`, `age`, `company`, `gender`, `name`, `phone`, `ps`, `address`, `email`, `wechat`, `nickname`, `position`) VALUES
(5, '', '', '男', '张钧杰', '15977602749', '', '', '', '', '张钧杰', ''),
(6, '', '', '男', '张英铭', '18677607234', '', '', '', '', '小张', '销售经理');

-- --------------------------------------------------------

--
-- 表的结构 `sign`
--

DROP TABLE IF EXISTS `sign`;
CREATE TABLE IF NOT EXISTS `sign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(255) DEFAULT NULL,
  `time_start` varchar(255) DEFAULT NULL,
  `uid` int(11) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `createtime` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `sign`
--

INSERT INTO `sign` (`id`, `status`, `time_start`, `uid`, `reason`, `createtime`, `name`) VALUES
(18, '0', '2020-10-1', 2, '123', '2020-10-19', NULL),
(17, '1', '2020-10-19', 3, '家里有事', '2020-10-19', NULL),
(16, '2', '2020-10-19', 30, '生病了', '2020-10-19', NULL),
(15, '0', '2020-10-19', 36, '忘了', '2020-10-19', NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
