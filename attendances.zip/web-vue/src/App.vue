<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>

#app,html,body{
  padding: 0;
  margin: 0;
  width: 100%;
  height: 100%;
}
</style>
